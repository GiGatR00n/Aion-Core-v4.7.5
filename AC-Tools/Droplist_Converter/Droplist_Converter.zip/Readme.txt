Just Drag the npc_drop.dat or npc_drop.xml file, over the Dat2Xml.exe file to convert the droplist file.

Copy your npc_drop.dat in this folder:

1. convert npc_drop.dat to npc_drop.xml (you can change or add record to the file)
2. npc_drop.xml back to npc_drop.dat